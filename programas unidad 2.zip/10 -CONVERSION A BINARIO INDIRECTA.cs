//Convertir un numero entero no negativoa su representacion binaria usando dos metodos que se llaman mutuamente
using System;
using System.Dynamic;

class Program
{
    static void BinarioA(int n)
    {
        if (n < 2)
        {
            Console.Write(n);
            return;
        }

        BinarioB(n / 2);
        Console.Write(n % 2);
    }

    static void BinarioB(int n)
    {
        if (n < 2)
        {
            Console.Write(n);
            return;
        }

        BinarioA(n / 2);
        Console.Write(n % 2);
    }

    static void Main()
    {
        Console.Write("Ingrese un numero entero: ");
        int n = int.Parse(Console.ReadLine());

        if (n < 0)
        {
            Console.WriteLine("Ingrese un valor entero positivo");
            return;
        }

        Console.Write("Binario: ");

        if (n == 0)
            Console.Write("0");
        else
            BinarioA(n);

        Console.WriteLine();

    }
}